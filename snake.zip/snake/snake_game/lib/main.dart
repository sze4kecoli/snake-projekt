import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const SnakeApp());
}

class SnakeApp extends StatelessWidget {
  const SnakeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kígyó Játék',
      theme: ThemeData(
        primarySwatch: Colors.green,
        brightness: Brightness.dark,
      ),
      home: const SnakeGame(),
    );
  }
}

class SnakeGame extends StatefulWidget {
  const SnakeGame({super.key});

  @override
  SnakeGameState createState() => SnakeGameState();
}

class SnakeGameState extends State<SnakeGame> {
  static const int rowSize = 15;
  static const int totalSquares = rowSize * rowSize;

  List<int> snake = [];
  int food = 0;
  String direction = 'right';
  Timer? timer;
  int score = 0;
  bool isGameRunning = false;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _initSnakePosition();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      generateNewFood();
      _focusNode.requestFocus();
    });
  }

  void _initSnakePosition() {
    // Kígyó középen spawnol
    int center = (rowSize * rowSize ~/ 2) - (rowSize ~/ 2);
    snake = [center, center + 1, center + 2];
    direction = 'right';
  }

  void startGame() {
    if (timer == null || !timer!.isActive) {
      setState(() {
        isGameRunning = true;
      });
      timer = Timer.periodic(const Duration(milliseconds: 200), (timer) {
        if (isGameRunning && mounted) {
          moveSnake();
        }
      });
    }
    _focusNode.requestFocus();
  }

  void stopGame() {
    setState(() {
      isGameRunning = false;
    });
    timer?.cancel();
    timer = null;
  }

  void moveSnake() {
    if (!mounted) return;
    
    setState(() {
      int newHead;

      switch (direction) {
        case 'down':
          newHead = snake.last + rowSize;
          break;
        case 'up':
          newHead = snake.last - rowSize;
          break;
        case 'left':
          newHead = snake.last - 1;
          break;
        default:
          newHead = snake.last + 1;
      }

      // Fal ütközés vizsgálat
      if (newHead < 0 ||
          newHead >= totalSquares ||
          (direction == 'right' && newHead % rowSize == 0) ||
          (direction == 'left' && newHead % rowSize == rowSize - 1)) {
        gameOver();
        return;
      }

      // Saját test ütközés
      if (snake.contains(newHead)) {
        gameOver();
        return;
      }

      // Evés
      if (newHead == food) {
        snake.add(newHead);
        score++;
        generateNewFood();
      } else {
        snake.add(newHead);
        snake.removeAt(0);
      }
    });
  }

  void generateNewFood() {
    List<int> availablePositions = [];
    for (int i = 0; i < totalSquares; i++) {
      if (!snake.contains(i)) {
        availablePositions.add(i);
      }
    }
    
    if (availablePositions.isEmpty) {
      timer?.cancel();
      setState(() {
        isGameRunning = false;
      });
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.emoji_events, color: Colors.amber, size: 30),
                SizedBox(width: 10),
                Text('Győztél! 🏆'),
              ],
            ),
            content: Text('Gratulálok! Kitöltötted a pályát!\nVégeredmény: $score pont'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  resetGame();
                },
                child: const Text('Új játék'),
              ),
            ],
          ),
        );
      }
    } else {
      setState(() {
        food = availablePositions[Random().nextInt(availablePositions.length)];
      });
    }
  }

  void gameOver() {
    stopGame();
    
    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.sentiment_very_dissatisfied, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text('Játék vége'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Végeredmény: $score pont', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text('Nyomd meg az "Új játék" gombot a folytatáshoz!'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                resetGame();
              },
              child: const Text('Új játék', style: TextStyle(color: Colors.green)),
            ),
          ],
        ),
      );
    }
  }

  void resetGame() {
    // Leállítjuk a régi timert
    stopGame();
    
    // Újrainicializáljuk a játékot
    setState(() {
      _initSnakePosition();
      score = 0;
      isGameRunning = false;
    });
    
    // Új ételt generálunk
    generateNewFood();
    
    // Automatikusan indítjuk a játékot
    startGame();
  }

  void changeDirection(String newDirection) {
    if ((newDirection == 'up' && direction != 'down') ||
        (newDirection == 'down' && direction != 'up') ||
        (newDirection == 'left' && direction != 'right') ||
        (newDirection == 'right' && direction != 'left')) {
      setState(() {
        direction = newDirection;
      });
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    _focusNode.dispose();
    super.dispose();
  }

  RawKeyEvent? _lastKeyEvent;
  
  void _handleKeyEvent(RawKeyEvent event) {
    if (_lastKeyEvent == event) return;
    _lastKeyEvent = event;
    
    if (event is RawKeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
        changeDirection('up');
      } else if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
        changeDirection('down');
      } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
        changeDirection('left');
      } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
        changeDirection('right');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return RawKeyboardListener(
      focusNode: _focusNode,
      onKey: _handleKeyEvent,
      child: GestureDetector(
        onTap: () {
          _focusNode.requestFocus();
        },
        child: Scaffold(
          backgroundColor: Colors.grey[900],
          appBar: AppBar(
            title: const Text(
              'KÍGYÓ JÁTÉK',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            centerTitle: true,
            elevation: 0,
            backgroundColor: Colors.black,
            actions: [
              Container(
                margin: const EdgeInsets.only(right: 16),
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      'PONTSZÁM: $score',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              // Irányító panel - INDÍTÁS, STOP, ÚJRA
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                decoration: BoxDecoration(
                  color: Colors.black,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: startGame,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 5,
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.play_arrow, size: 20),
                            SizedBox(width: 8),
                            Text('INDÍTÁS', style: TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: stopGame,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 5,
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.stop, size: 20),
                            SizedBox(width: 8),
                            Text('STOP', style: TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: resetGame,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 5,
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.refresh, size: 20),
                            SizedBox(width: 8),
                            Text('ÚJRA', style: TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Játék állapot jelző
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isGameRunning ? Colors.green : Colors.red,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      isGameRunning ? 'JÁTÉK FUT' : 'JÁTÉK MEGÁLLÍTVA',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
              
              // Játéktábla
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black45,
                          blurRadius: 20,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: AspectRatio(
                        aspectRatio: 1,
                        child: GridView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: totalSquares,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: rowSize,
                            childAspectRatio: 1,
                          ),
                          itemBuilder: (context, index) {
                            Color cellColor;
                            if (snake.contains(index)) {
                              cellColor = Colors.green.shade600;
                            } else if (index == food) {
                              cellColor = Colors.red.shade500;
                            } else {
                              cellColor = Colors.grey.shade800;
                            }
                            
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 100),
                              margin: const EdgeInsets.all(1.2),
                              decoration: BoxDecoration(
                                color: cellColor,
                                borderRadius: BorderRadius.circular(4),
                                boxShadow: snake.contains(index)
                                    ? [
                                        BoxShadow(
                                          color: Colors.green.withValues(alpha: 0.3),
                                          blurRadius: 2,
                                          spreadRadius: 1,
                                        )
                                      ]
                                    : null,
                              ),
                              child: index == food
                                  ? const Center(
                                      child: Icon(
                                        Icons.circle,
                                        size: 10,
                                        color: Colors.white,
                                      ),
                                    )
                                  : null,
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              
              // Információs sáv
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.8),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.keyboard, color: Colors.white70, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Használd a nyilakat a kígyó irányításához',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}