import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:snake_game/main.dart';

void main() {
  testWidgets('Snake app smoke test', (WidgetTester tester) async {
    // Build our Snake app and trigger a frame.
    await tester.pumpWidget(SnakeApp());

    // Ellenőrizhetjük, hogy a játék GridView megjelenik.
    expect(find.byType(GridView), findsOneWidget);

    // Ellenőrizhetjük, hogy a kígyó legalább egy zöld doboz.
    expect(find.byWidgetPredicate(
      (widget) =>
          widget is Container && widget.color == Colors.green,
    ), findsWidgets);
  });
}